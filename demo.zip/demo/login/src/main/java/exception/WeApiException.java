package exception;


/**
 * 自定义API异常
 * Created by vt
 */
public class WeApiException extends RuntimeException {

    private String message;
    private String code;

    public WeApiException(String message) {
        super(message);
        this.code = null;
        this.message = message;
    }

    public WeApiException(String message, String code) {
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }


}
