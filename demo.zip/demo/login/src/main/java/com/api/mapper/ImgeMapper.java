package com.api.mapper;

import com.api.entity.Imge;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author vt
 * @since 2023-02-09
 */
public interface ImgeMapper extends BaseMapper<Imge> {

}
