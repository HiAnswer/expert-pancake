package com.api.service.impl;

import com.api.entity.TPermission;
import com.api.mapper.TPermissionMapper;
import com.api.service.TPermissionService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author vt
 * @since 2023-02-08
 */
@Service
public class TPermissionServiceImpl extends ServiceImpl<TPermissionMapper, TPermission> implements TPermissionService {

}
