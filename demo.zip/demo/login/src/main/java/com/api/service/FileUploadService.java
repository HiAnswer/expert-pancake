package com.api.service;


import java.io.File;
import java.io.IOException;
import java.io.InputStream;

/**
 * 文件上传
 */
public interface FileUploadService {

    /**
     * 文件上传
     *
     * @param file     the file
     * @param fileName the file name
     * @param folder   the folder
     * @return the string
     */
    String fileUpload(File file, String fileName, String folder);

    /**
     * 文件流上传
     *
     * @param inputStream the input stream
     * @param fileSize    the file size
     * @param fileName    the file name
     * @param folder      the folder
     * @return the string
     * @throws IOException the io exception
     */
    String fileUpload(InputStream inputStream, long fileSize, String fileName, String folder) throws IOException;
}