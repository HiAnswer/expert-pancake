package com.api.mapper;

import com.api.entity.UserDb;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author vt
 * @since 2023-02-08
 */
public interface UserDbMapper extends BaseMapper<UserDb> {

}
