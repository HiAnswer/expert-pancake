package com.api.service;

import com.api.entity.TUserRole;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author vt
 * @since 2023-02-14
 */
public interface TUserRoleService extends IService<TUserRole> {

}
