package com.api.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author vt
 * @since 2023-02-14
 */
@RestController
@RequestMapping("/t-user-role")
public class TUserRoleController {

}

