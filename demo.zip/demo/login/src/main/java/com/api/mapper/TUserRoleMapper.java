package com.api.mapper;

import com.api.entity.TUserRole;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author vt
 * @since 2023-02-14
 */
public interface TUserRoleMapper extends BaseMapper<TUserRole> {

}
