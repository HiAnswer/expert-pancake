package com.api.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author vt
 * @since 2023-02-08
 */
@RestController
@RequestMapping("/t-permission")
public class TPermissionController {

}

