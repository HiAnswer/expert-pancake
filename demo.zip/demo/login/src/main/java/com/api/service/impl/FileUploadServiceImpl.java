package com.api.service.impl;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.io.IoUtil;
import com.api.service.FileUploadService;
import com.qcloud.cos.ClientConfig;
import com.qcloud.cos.auth.BasicCOSCredentials;
import com.qcloud.cos.auth.COSCredentials;
import com.qcloud.cos.model.ObjectMetadata;
import com.qcloud.cos.model.PutObjectRequest;
import com.qcloud.cos.region.Region;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import com.qcloud.cos.COSClient;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.UUID;

/**
 * 文件上传
 */
@Service
public class FileUploadServiceImpl implements FileUploadService {

    @Value("${system.resource.local-store}")
    private Boolean localStore;

    @Value("${system.resource.file.location}")
    private String fileLocation;

    @Value("${system.resource.file.url}")
    private String fileUrl;

    @Value("${system.resource.file.allow}")
    private String allow;

    @Value("${system.resource.qcloud.region}")
    private String region;

    @Value("${system.resource.qcloud.cdn}")
    private String cdn;

    @Value("${system.resource.qcloud.url}")
    private String url;

    @Value("${system.resource.qcloud.bucket}")
    private String bucket;

    @Value("${system.resource.qcloud.secret-id}")
    private String secretId;

    @Value("${system.resource.qcloud.secret-key}")
    private String secretKey;

    @Override
    public String fileUpload(File file, String fileName, String folder) {
        if (localStore) {
            if (Arrays.stream(allow.split("\\|")).anyMatch(fileName::endsWith)) {
                String randomDir = UUID.randomUUID().toString();
                FileUtil.mkdir(String.format("%s/%s/%s", fileLocation, folder, randomDir));
                File destFile = new File(String.format("%s/%s/%s/%s", fileLocation, folder, randomDir, fileName));
                FileUtil.copyFile(file, destFile);
                return String.format("%s/%s/%s/%s", fileUrl, folder, randomDir, fileName);
            } else {
                return null;
            }
        } else {
            String filePath = String.format("%s/%s/%s", folder, UUID.randomUUID(), fileName);
            COSClient cosClient = getCOSClient();
            PutObjectRequest putObjectRequest = new PutObjectRequest(bucket, filePath, file);
            cosClient.putObject(putObjectRequest);
            return cdn + "/" + filePath;
        }
    }

    @Override
    public String fileUpload(InputStream inputStream, long fileSize, String fileName, String folder) throws IOException {
        if (localStore) {
            return localUpload(inputStream, fileName, folder);
        } else {
            return ossUpload(cdn, inputStream, fileSize, fileName, folder);
        }
    }


    private String localUpload(InputStream inputStream, String fileName, String folder) throws IOException {
        if (Arrays.stream(allow.split("\\|")).anyMatch(fe -> fileName.endsWith(fe))) {
            String randomDir = UUID.randomUUID().toString();
            FileUtil.mkdir(String.format("%s/%s/%s", fileLocation, folder, randomDir));
            File destFile = new File(String.format("%s/%s/%s/%s", fileLocation, folder, randomDir, fileName));
            try (FileOutputStream fileOutputStream = new FileOutputStream(destFile)) {
                IoUtil.copy(inputStream, fileOutputStream);
            }
            return String.format("%s/%s/%s/%s", fileUrl, folder, randomDir, fileName);
        } else {
            return null;
        }
    }

    private String ossUpload(String url, InputStream inputStream, long fileSize, String fileName, String folder) {
        COSClient cosClient = getCOSClient();
        String filePath = String.format("%s/%s/%s", folder, UUID.randomUUID(), fileName);
        ObjectMetadata objectMetadata = new ObjectMetadata();
        objectMetadata.setContentLength(fileSize);
        PutObjectRequest putObjectRequest = new PutObjectRequest(bucket, filePath, inputStream, objectMetadata);
        cosClient.putObject(putObjectRequest);
        return url + "/" + filePath;
    }

    private COSClient getCOSClient() {
        COSCredentials cred = new BasicCOSCredentials(secretId, secretKey);
        Region qRegion = new Region(region);
        ClientConfig clientConfig = new ClientConfig(qRegion);
        COSClient cosClient = new COSClient(cred, clientConfig);
        return cosClient;
    }

}
