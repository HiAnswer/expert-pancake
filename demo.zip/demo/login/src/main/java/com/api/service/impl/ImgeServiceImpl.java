package com.api.service.impl;

import com.api.entity.Imge;
import com.api.mapper.ImgeMapper;
import com.api.service.ImgeService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author vt
 * @since 2023-02-09
 */
@Service
public class ImgeServiceImpl extends ServiceImpl<ImgeMapper, Imge> implements ImgeService {

}
