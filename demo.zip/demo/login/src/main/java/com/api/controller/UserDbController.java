package com.api.controller;


import com.api.entity.UserDb;
import com.api.entity.UserVM;
import com.api.service.UserDbService;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import exception.WeApiException;
import lombok.AllArgsConstructor;
import org.apache.tomcat.util.codec.binary.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import util.R;

import javax.validation.Valid;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author vt
 * @since 2023-02-08
 */
@RestController
@RequestMapping("/userdb")
@AllArgsConstructor
@Validated
public class UserDbController {

    private UserDbService userService;

    /*
     * 注册
     * */
    @PostMapping("/register")
    public R register(@RequestBody UserVM userVM) {
        QueryWrapper<UserDb> query = Wrappers.query();
        query.eq("phone",userVM.getPhone());
        UserDb one = userService.getOne(query);
        boolean T = (Objects.equals(userVM.getPassword(), userVM.getConfirmPassword()));
        if(!T){
            return R.er(false,"两次输入密码不相同！");
        }
        if(!Objects.isNull(one)){
            return R.er(false,"该用户已存在，请返回直接登录！");
        }
        UserDb userDb = new UserDb();
        userDb.setPassword(userVM.getPassword());
        userDb.setPhone(userVM.getPhone());
        boolean save = userService.save(userDb);
        if(!save){
            return R.er(false,"注册失败！");
        }
        return R.ok("注册成功！");
    }



    /**
     * 用户登录
     *
     * @param user          用户信息
     * @param bindingResult 参数校验结果
     * @return 登录结果
     */
    @PostMapping("/login")
    public R login(@RequestBody @Valid UserDb user, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            String errorMessage = Objects.requireNonNull(bindingResult.getFieldError()).getDefaultMessage();
            return R.er(HttpStatus.BAD_REQUEST.value(), errorMessage);
        }
        UserDb loginUser = userService.login(user);
        if (loginUser == null) {
            return R.er(HttpStatus.UNAUTHORIZED.value(), "用户名或密码错误");
        } else {
            return R.ok("登陆成功！");
        }
    }


    /*
     * 注销
     * */
   @DeleteMapping("/delete/{id}")
    public R out(@PathVariable String id) {
       userService.removeById(id);
        return R.ok("注销！");
    }

}

