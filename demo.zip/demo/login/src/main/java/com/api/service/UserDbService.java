package com.api.service;


import com.api.entity.UserDb;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author vt
 * @since 2023-02-08
 */
public interface UserDbService extends IService<UserDb> {
    UserDb login(UserDb user);
}
