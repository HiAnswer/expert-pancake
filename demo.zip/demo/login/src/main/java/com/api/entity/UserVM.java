package com.api.entity;

import lombok.Data;
@Data
public class UserVM {

        /**
         * 手机号
         */
        private String phone;
        /**
         * 账号
         */
        private String account;
        /**
         * 密码
         **/
        private String password;
        /**
         * 确认密码
         **/
        private String confirmPassword;
        /**
         * 用户角色：1 学生  2 家长
         */
        private Integer roleId;

}
