package com.api.service.impl;

import com.api.entity.UserDb;
import com.api.mapper.UserDbMapper;
import com.api.service.UserDbService;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author vt
 * @since 2023-02-08
 */
@Service
public class UserDbServiceImpl extends ServiceImpl<UserDbMapper, UserDb> implements UserDbService {


        public UserDb login(UserDb user) {
            QueryWrapper<UserDb> query = Wrappers.query();
            query.eq("username", user.getUserName());
            query.eq("password", user.getPassword());
            return baseMapper.selectOne(query);
        }
}
