package com.api.controller;

import com.api.entity.Imge;
import com.api.service.FileUploadService;
import com.api.service.ImgeService;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import util.R;

import javax.servlet.http.HttpServletRequest;
import java.io.*;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/image")
@AllArgsConstructor
public class ImageController {



    private ImgeService imageService;
    private FileUploadService fileUploadService;

    //新增图像
    @PostMapping("/insert")
    @ApiOperation(value = "新增", notes = "新增")
    public R insert(@RequestBody Imge image){
        imageService.save(image);
        return R.ok(image,"新增成功");
    }

    //修改图像
    @PostMapping("/update")
    @ApiOperation(value = "修改", notes = "修改")
    public R update(@RequestBody Imge image){
        imageService.updateById(image);
        return R.ok(image,"修改成功");
    }

    //删除图像
    @DeleteMapping(value="/delete/{id}")
    @ApiOperation(value = "删除", notes = "删除")
    public R delete(@PathVariable Long id){
        imageService.removeById(id);
        return R.ok("删除成功");
    }

    //查看所有对象数据（不分页）
    @GetMapping(value = "/list")
    @ApiOperation(value = "不分页查询", notes = "不分页查询")
    public R list(Imge image){
        QueryWrapper<Imge> wrapper = new QueryWrapper<>();
        wrapper.eq(image.getImageType()!=null,"image_type", image.getImageType());
        wrapper.orderByAsc("sort");
        List<Imge> list = imageService.list(wrapper);
        return R.ok(list,"查看所有对象数据（不分页）");
    }

    //查看所有对象数据（分页）
    @PostMapping(value = "/pageList")
    @ApiOperation(value = "分页查询", notes = "分页查询")
    public R pageList(@RequestBody Page page) {
        QueryWrapper<Imge> query = new QueryWrapper<>();
        //根据 image_type 的类型进行查询  1  代表用户图像  2 代表轮播图
       // query.eq("image_type",pageRequestVM.getImageType());
        query.orderByAsc("sort");
        page = imageService.page(page,query);
        return R.ok(page,"查看所有对象数据（分页）");
    }


    //上传图片
    @RequestMapping(value = "/upload",method = RequestMethod.POST)
    @ResponseBody
    @ApiOperation(value = "上传图片", notes = "上传图片")
    public String upload(HttpServletRequest request) throws IOException {
        MultipartHttpServletRequest multipartHttpServletRequest = (MultipartHttpServletRequest) request;
        MultipartFile multipartFile = multipartHttpServletRequest.getFile("file");
        String fileName = multipartFile.getOriginalFilename();
        String filePath;
        File localTempFile = File.createTempFile(String.format("%s_%s", UUID.randomUUID().toString(), multipartFile.getOriginalFilename()), "");
        try (InputStream inputStream = multipartFile.getInputStream()) {
            byte[] buffer = new byte[inputStream.available()];
            inputStream.read(buffer);
            try (OutputStream outStream = new FileOutputStream(localTempFile)) {
                outStream.write(buffer);
                filePath = fileUploadService.fileUpload(localTempFile, fileName, "img");
            }
        } catch (IOException e) {
            return "文件上传失败！";
        }
        return filePath;
    }

}
