package util;

import org.springframework.util.Assert;

import javax.servlet.http.HttpServletRequest;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.UUID;

/**
 * @author vt
 * @description MyUtils
 */
public class MyUtils {
    private static final String SYMBOLS = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final Random RANDOM = new SecureRandom();

    /**
     * 获取随机字符串 Nonce Str 32位
     *
     * @return String 随机字符串
     */
    public static String generateNonceStr(Integer Str) {

        char[] nonceChars = new char[Str];
        for (int index = 0; index < nonceChars.length; ++index) {
            nonceChars[index] = SYMBOLS.charAt(RANDOM.nextInt(SYMBOLS.length()));
        }
        return new String(nonceChars);
    }

    /**
     * 生成随机六位数数字
     *
     * @return
     */
    public static String getSixNumber() {
        String checkCode = String.valueOf((int) ((Math.random() * 9 + 1) * 100000));
        return checkCode;
    }

    /**
     * 生成订单号
     *
     * @return
     */
    public static String getOrderNo() {
        String orderNo = "";
        String sdf = new SimpleDateFormat("yyyyMMddHHMMSSsss").format(new Date());
        orderNo = UUID.randomUUID().toString().substring(0, 8);
        orderNo = orderNo + sdf;
        return orderNo;
    }

    /**
     * 验证登录密码
     * 8-16位字符
     * 只能包含大小写字母，数字以及标点符号（除空格）
     * 大小写字母、数字和标点符号至少包含两种
     *
     * @param newPwd
     * @return
     */
    public static boolean isLetterDigit(String newPwd) {
        int bigCount = 0;
        int a = 0;
        String aa = "~!@#$%^&*()_+|<>,.?/:;'\\[\\]{}";
        Assert.isTrue(newPwd.length() <= 16 && newPwd.length() >= 8, "密码长度有误");
        for (int x = 0; x < newPwd.length(); x++) {
            //char charAt(int index):获取指定索引位置的字符
            char ch = newPwd.charAt(x);
            //判断
            if (ch >= 'A' && ch <= 'Z') {
                bigCount++;
                if (a >= 1) {
                    a = 2;
                } else {
                    a = 1;
                }
            } else if (ch >= 'a' && ch <= 'z') {
                bigCount++;
                if (a >= 1) {
                    a = 2;
                } else {
                    a = 1;
                }
            } else if (ch >= '0' && ch <= '9') {
                bigCount++;
                if (a >= 1) {
                    a = 2;
                } else {
                    a = 1;
                }
            } else if (aa.contains(String.valueOf(ch))) {
                bigCount++;
                if (a >= 1) {
                    a = 2;
                } else {
                    a = 1;
                }
            }

        }
        Assert.isTrue(bigCount == newPwd.length(), "密码字符错误");
        Assert.isTrue(a == 2, "大小写字母、数字和标点符号至少包含两种");
        return true;
    }


    /**
     * 包含大小写字母及数字且在6-12位
     * 是否包含
     *
     * @param str
     * @return
     */
    public static boolean isLetterDigit1(String str) {
        boolean isDigit = false;//定义一个boolean值，用来表示是否包含数字
        boolean isLetter = false;//定义一个boolean值，用来表示是否包含字母
        for (int i = 0; i < str.length(); i++) {
            if (Character.isDigit(str.charAt(i))) {   //用char包装类中的判断数字的方法判断每一个字符
                isDigit = true;
            } else if (Character.isLetter(str.charAt(i))) {  //用char包装类中的判断字母的方法判断每一个字符
                isLetter = true;
            }
        }
        String regex = "^[a-zA-Z0-9]{8,16}$";
        boolean isRight = isDigit && isLetter && str.matches(regex);
        return isRight;
    }

    public static String getIp(HttpServletRequest request) {
        // 获取请求ip地址
        String ip = request.getHeader("x-forwarded-for");
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        if (ip.indexOf(",") != -1) {
            String[] ips = ip.split(",");
            ip = ips[0].trim();
        }
        return ip;
    }
}
